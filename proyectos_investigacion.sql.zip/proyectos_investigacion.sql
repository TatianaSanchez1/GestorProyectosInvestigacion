-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 11-03-2022 a las 05:13:16
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyectos_investigacion`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `directores`
--

CREATE TABLE `directores` (
  `id_director` int(11) NOT NULL,
  `nombre_director` varchar(100) COLLATE utf8mb4_spanish_ci NOT NULL,
  `area` varchar(100) COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `directores`
--

INSERT INTO `directores` (`id_director`, `nombre_director`, `area`) VALUES
(1, 'mario zapata', 'fisica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyectos`
--

CREATE TABLE `proyectos` (
  `id` int(11) NOT NULL,
  `id_proyecto` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_spanish_ci NOT NULL,
  `descripcion` varchar(500) COLLATE utf8mb4_spanish_ci NOT NULL,
  `obj_generales` varchar(1000) COLLATE utf8mb4_spanish_ci NOT NULL,
  `obj_especificos` varchar(1000) COLLATE utf8mb4_spanish_ci NOT NULL,
  `presupuesto` decimal(10,2) NOT NULL,
  `fecha_inicial` date NOT NULL,
  `fecha_final` date NOT NULL,
  `director` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `proyectos`
--

INSERT INTO `proyectos` (`id`, `id_proyecto`, `nombre`, `descripcion`, `obj_generales`, `obj_especificos`, `presupuesto`, `fecha_inicial`, `fecha_final`, `director`) VALUES
(2, '1', 'prueba', 'Nunc tincidunt orci sed arcu tempus, sed feugiat urna interdum. Morbi accumsan pellentesque justo, eget facilisis magna consectetur dapibus. In tincidunt nunc vitae libero semper, vel hendrerit orci aliquet. Sed at est vel velit venenatis dapibus. Integer eu quam sit amet orci bibendum tincidunt.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ullamcorper facilisis risus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nullam vel eros elementum, suscipit tellus aliquam, mattis tellus.', 'Maecenas rutrum, lorem laoreet lacinia consectetur, enim odio sollicitudin neque, vel tincidunt purus eros sit amet arcu. Nam non velit eu augue elementum iaculis quis in massa. Donec sit amet lacus vel justo mollis elementum a nec odio. Praesent tempus posuere lacus laoreet pretium. Mauris rhoncus interdum elit. Duis velit dui, mattis eu lorem non, viverra commodo turpis.', '200000.00', '2022-03-24', '2022-04-01', '1'),
(4, '2', 'prueba2', 'Maecenas rutrum, lorem laoreet lacinia consectetur, enim odio sollicitudin neque, vel tincidunt purus eros sit amet arcu. Nam non velit eu augue elementum iaculis quis in massa. Donec sit amet lacus vel justo mollis elementum a nec odio. Praesent tempus posuere lacus laoreet pretium. Mauris rhoncus interdum elit. Duis velit dui, mattis eu lorem non, viverra commodo turpis.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ullamcorper facilisis risus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nullam vel eros elementum, suscipit tellus aliquam, mattis tellus.', 'Nunc tincidunt orci sed arcu tempus, sed feugiat urna interdum. Morbi accumsan pellentesque justo, eget facilisis magna consectetur dapibus. In tincidunt nunc vitae libero semper, vel hendrerit orci aliquet. Sed at est vel velit venenatis dapibus. Integer eu quam sit amet orci bibendum tincidunt.', '30000.00', '2022-03-22', '2022-03-18', ''),
(7, '3', 'asasa', 'asdasdad', 'sadsadsas', 'asdasdas', '12312.00', '2022-03-18', '2022-04-05', ''),
(8, '', '', '', '', '', '0.00', '0000-00-00', '0000-00-00', ''),
(9, '5', 'asdasd', 'asdasda', 'asdadsas', 'asdadsad', '212123.00', '2022-02-27', '2022-04-05', '1'),
(10, '6', 'asdas', 'asdasda', 'asasdas', 'asdasasd', '213121.00', '2022-03-26', '2022-04-05', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre_completo` varchar(100) COLLATE utf8mb4_spanish_ci NOT NULL,
  `correo` varchar(100) COLLATE utf8mb4_spanish_ci NOT NULL,
  `usuario` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `contrasena` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre_completo`, `correo`, `usuario`, `contrasena`, `fecha`) VALUES
(1, 'maria', 'maria@correo.com', 'maria', '123', '2022-03-10 21:26:53');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `directores`
--
ALTER TABLE `directores`
  ADD PRIMARY KEY (`id_director`);

--
-- Indices de la tabla `proyectos`
--
ALTER TABLE `proyectos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `directores`
--
ALTER TABLE `directores`
  MODIFY `id_director` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `proyectos`
--
ALTER TABLE `proyectos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
